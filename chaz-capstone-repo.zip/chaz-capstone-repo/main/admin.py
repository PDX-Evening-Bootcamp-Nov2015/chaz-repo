from django.contrib import admin
from .models import Airportaa, Airportunited


admin.site.register(Airportaa)
admin.site.register(Airportunited)

# Register your models here.
