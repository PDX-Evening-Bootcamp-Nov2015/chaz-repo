$(document).ready(function() {
    //select2 adds additional capabilities to the standard selectbox for choosing an airport
    $(".js-example-basic-single").select2();
    $('#openModal').bind('click', function() {
        $("#myModal").modal();
    })
    //'load' button is for development only! it populates the database with thousands of airports. Only use
    //it once when a new database has been setup
    document.getElementById('load').addEventListener("click", clickIt);
    document.getElementById('submit').addEventListener("click", clickIt);
    //ajaxData is the main object that stores information before and after ajax calls
    var ajaxData = {
        "task": "initial",
        "airport": "",
        "url": "/getairports/",
        "lat": "45.52",
        "lon": "-122.68"
    }
    //initial ajaxcall is executed on pageload to load list of airports for the selectbox
    ajaxCall();
    //initialize function loads the google map centered on Portland
    initialize();


    function initialize() {
        var mapProp = {
            center: new google.maps.LatLng(ajaxData.lat, ajaxData.lon),
            zoom: 5,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        var map = new google.maps.Map(document.getElementById("mapDIV"), mapProp);
        var myCenter = new google.maps.LatLng(ajaxData.lat, ajaxData.lon);
        var marker = new google.maps.Marker({
            position: myCenter,
        });
        marker.setMap(map);
    }


    //populateSelects populates the selectbox filled with airports
    function populateSelects(result) {
        codeList = result;
        var sel = document.getElementById("code");
        for (var i = 0; i < codeList.length; i++) {
            var opt = document.createElement('option');
            opt.innerHTML = codeList[i];
            opt.value = codeList[i];
            sel.appendChild(opt);
        }
    }


    //clickit function takes click events and prepares ajaxcalls
    function clickIt(event) {
        whichClick = event.target.id;
        if (whichClick === "load") {
            ajaxData["task"] = "load";
            ajaxData["url"] = "/load/";
            ajaxCall();
        } else if (whichClick === "submit") {
            airportCode = $('#code').select2('data')[0].id.substr(0, 3);
            ajaxData["task"] = "submitIt";
            ajaxData["airport"] = airportCode;
            ajaxData["url"] = "/getmilescoords/";
            ajaxCall();
        }
    }


    //ajaxcalls to load airport data, price information, and populate mileage table
    function ajaxCall() {
        var response = $.ajax({
            type: 'GET',
            data: ajaxData,
            url: ajaxData["url"],
            contentType: "application/json",
            success: function(result) {
                if (ajaxData["task"] === "load") {
                    console.log("airports loaded. Don't do this again.")
                } else if (ajaxData["task"] === "initial") {
                    populateSelects(result["info"]);
                } else if (ajaxData["task"] === "submitIt") {
                    var aa = result["info"][0];
                    var un = result["info"][1];
                    ajaxData["lat"] = result["info"][0][3];
                    ajaxData["lon"] = result["info"][0][4];
                    $('#AE').html(result["info"][0][0] + "k");
                    $('#AB').html(result["info"][0][1] + "k");
                    $('#AF').html(result["info"][0][2] + "k");
                    $('#UE').html(result["info"][1][0] + "k");
                    $('#UB').html(result["info"][1][1] + "k");
                    $('#UF').html(result["info"][1][2] + "k");
                    if (aa[0] > un[0]) {
                        $('#UE').css("background-color", "rgb(132, 254, 132)");
                    } else if (aa[0] === un[0]) {
                        $('#UE').css("background-color", "white");
                        $('#AE').css("background-color", "white");
                    } else if (aa[0] < un[0]) {
                        $('#AE').css("background-color", "rgb(132, 254, 132)");
                    }
                    if (aa[1] > un[1]) {
                        $('#UB').css("background-color", "rgb(132, 254, 132)");
                    } else if (aa[1] === un[1]) {
                        $('#UB').css("background-color", "white");
                        $('#AB').css("background-color", "white");
                    } else if (aa[1] < un[1]) {
                        $('#AB').css("background-color", "rgb(132, 254, 132)");
                    }
                    if (aa[2] > un[2]) {
                        $('#UF').css("background-color", "rgb(132, 254, 132)");
                    } else if (aa[2] === un[2]) {
                        $('#UF').css("background-color", "white");
                        $('#AF').css("background-color", "white");
                    } else if (aa[2] < un[2]) {
                        $('#AF').css("background-color", "rgb(132, 254, 132)");
                    }
                    initialize();
                }
            },
            error: function(result) {
                console.log("error");
            }
        });
    };
});
