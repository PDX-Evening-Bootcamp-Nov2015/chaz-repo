from django.db import models
from django.contrib.auth.models import User
from datetime import datetime
from random import randint

class Airportaa(models.Model):
    city = models.CharField(max_length=30)
    airportcode = models.CharField(max_length=30)
    country = models.CharField(max_length=100)
    countrycode = models.CharField(max_length=30)
    region = models.CharField(max_length=30)
    airline = models.CharField(max_length=30)
    lat = models.CharField(max_length=30)
    lon = models.CharField(max_length=30)


    def __str__(self):
        return"city= {}, airportcode= {}, country {}, countrycode {}, region {}, airline {}, lat {}, lon {}".format(self.city, self.airportcode, self.country, self.countrycode, self.region, self.airline, self.lat, self.lon)

class Airportunited(models.Model):
    city = models.CharField(max_length=30)
    airportcode = models.CharField(max_length=30)
    country = models.CharField(max_length=100)
    countrycode = models.CharField(max_length=30)
    region = models.CharField(max_length=30)
    airline = models.CharField(max_length=30)


    def __str__(self):
        return"city= {}, airportcode= {}, country {}, countrycode {}, region {}, airline {}".format(self.city, self.airportcode, self.country, self.countrycode, self.region, self.airline)
